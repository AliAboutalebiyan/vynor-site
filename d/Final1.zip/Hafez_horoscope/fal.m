firstPage = 5;
lastPage = 500;

randomSource = java.security.SecureRandom();
page = firstPage + double(randomSource.nextInt(int32(lastPage - firstPage + 1)));
messageStart = char([1601 1575 1604 32 1588 1605 1575 32 1583 1585 32 1589 1601 1581 1607 32]);
messageEnd = char([32 1575 1587 1578 46]);
fprintf('%s%d%s\n', messageStart, page, messageEnd);

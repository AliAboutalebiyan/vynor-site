firstPage = 5;
lastPage = 500;

randomSource = java.security.SecureRandom();
page = firstPage + double(randomSource.nextInt(int32(lastPage - firstPage + 1)));
fprintf('Your Hafez fortune is on page %d.\n', page);

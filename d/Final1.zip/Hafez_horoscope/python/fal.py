import secrets
import sys

sys.stdout.reconfigure(encoding='utf-8')

first_page = 5
last_page = 500

page = first_page + secrets.randbelow(last_page - first_page + 1)
print(f'\u0641\u0627\u0644 \u0634\u0645\u0627 \u062f\u0631 \u0635\u0641\u062d\u0647 {page} \u0627\u0633\u062a.')

import secrets

first_page = 5
last_page = 500

page = first_page + secrets.randbelow(last_page - first_page + 1)
print(f'Your Hafez fortune is on page {page}.')

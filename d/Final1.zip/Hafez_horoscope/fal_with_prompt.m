firstPage = 5;
lastPage = 500;

prompt = char([1606 1740 1578 32 1705 1606 1740 1583 32 1608 32 1601 1575 1578 1581 1607 32 1576 1601 1585 1587 1578 1740 1583 32 1608 32 1575 1740 1606 1578 1585 32 1585 1575 32 1576 1586 1606 1740 1583 58 32]);
input(prompt, 's');

randomSource = java.security.SecureRandom();
page = firstPage + double(randomSource.nextInt(int32(lastPage - firstPage + 1)));
messageStart = char([1601 1575 1604 32 1588 1605 1575 32 1583 1585 32 1589 1601 1581 1607 32]);
messageEnd = char([32 1575 1587 1578 46]);
fprintf('%s%d%s\n', messageStart, page, messageEnd);
